void test() {}
int main() {
  void *p = (void *)(test);
  return 0;
}